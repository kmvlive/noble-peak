:HL["/_next/static/chunks/0hl83ukzsu.zc.css","style"]
:HL["/assets/2026-07-20_11-32-13.png","image"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"126ShRhzR3u-AGWsZm3IG"}
