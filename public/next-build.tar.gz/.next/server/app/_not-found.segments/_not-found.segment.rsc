1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/0~cegkrefnh.4.js","/_next/static/chunks/074oan_yyv6q9.js","/_next/static/chunks/00-csyj9a6t-x.js","/_next/static/chunks/0vby~20omsm91.js","/_next/static/chunks/0w2yc0gnvjmpo.js"],"default"]
3:I[37457,["/_next/static/chunks/0~cegkrefnh.4.js","/_next/static/chunks/074oan_yyv6q9.js","/_next/static/chunks/00-csyj9a6t-x.js","/_next/static/chunks/0vby~20omsm91.js","/_next/static/chunks/0w2yc0gnvjmpo.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"126ShRhzR3u-AGWsZm3IG"}
