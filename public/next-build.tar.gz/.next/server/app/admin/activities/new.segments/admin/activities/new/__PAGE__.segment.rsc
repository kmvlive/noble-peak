1:"$Sreact.fragment"
2:I[28532,["/_next/static/chunks/0~cegkrefnh.4.js","/_next/static/chunks/074oan_yyv6q9.js","/_next/static/chunks/00-csyj9a6t-x.js","/_next/static/chunks/0vby~20omsm91.js","/_next/static/chunks/0w2yc0gnvjmpo.js","/_next/static/chunks/0lhjhbc5pmhso.js","/_next/static/chunks/0fu736e9r3tv3.js","/_next/static/chunks/09pcjnw0~d.p4.js"],"AdminActivityForm"]
3:I[97367,["/_next/static/chunks/0~cegkrefnh.4.js","/_next/static/chunks/074oan_yyv6q9.js","/_next/static/chunks/00-csyj9a6t-x.js","/_next/static/chunks/0vby~20omsm91.js","/_next/static/chunks/0w2yc0gnvjmpo.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/0fu736e9r3tv3.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/09pcjnw0~d.p4.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"126ShRhzR3u-AGWsZm3IG"}
5:null
