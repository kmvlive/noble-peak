1:"$Sreact.fragment"
2:I[88355,["/_next/static/chunks/0~cegkrefnh.4.js","/_next/static/chunks/074oan_yyv6q9.js","/_next/static/chunks/00-csyj9a6t-x.js","/_next/static/chunks/0vby~20omsm91.js","/_next/static/chunks/0w2yc0gnvjmpo.js","/_next/static/chunks/0lhjhbc5pmhso.js","/_next/static/chunks/15rt09g8b3sfx.js"],"AdminMenuManager"]
3:I[97367,["/_next/static/chunks/0~cegkrefnh.4.js","/_next/static/chunks/074oan_yyv6q9.js","/_next/static/chunks/00-csyj9a6t-x.js","/_next/static/chunks/0vby~20omsm91.js","/_next/static/chunks/0w2yc0gnvjmpo.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{"menuType":"client","title":"Меню для клиентов","description":"Управление пунктами навигационного меню в личном кабинете клиента"}],[["$","script","script-0",{"src":"/_next/static/chunks/15rt09g8b3sfx.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"126ShRhzR3u-AGWsZm3IG"}
5:null
