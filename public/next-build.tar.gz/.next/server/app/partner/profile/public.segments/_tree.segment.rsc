:HL["/_next/static/chunks/0hl83ukzsu.zc.css","style"]
:HL["/_next/static/media/caa3a2e1cccd8315-s.p.09~u27dqhyhd6.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/assets/2026-07-20_11-32-13.png","image"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"partner","param":null,"prefetchHints":0,"slots":{"children":{"name":"profile","param":null,"prefetchHints":0,"slots":{"children":{"name":"public","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}}}}}},"staleTime":300,"buildId":"126ShRhzR3u-AGWsZm3IG"}
