var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/login/route.js")
R.c("server/chunks/[root-of-the-server]__0wgl0~c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/packages_shared_src_index_ts_0~ken~n._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_login_route_actions_0o428.q.js")
R.m(45543)
module.exports=R.m(45543).exports
