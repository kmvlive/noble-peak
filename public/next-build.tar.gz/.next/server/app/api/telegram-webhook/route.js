var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/telegram-webhook/route.js")
R.c("server/chunks/[root-of-the-server]__0vxa3xs._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_telegram-webhook_route_actions_0l1m_ai.js")
R.m(67579)
module.exports=R.m(67579).exports
